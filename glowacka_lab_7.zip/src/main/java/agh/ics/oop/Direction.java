package agh.ics.oop;

public enum Direction {
    F,
    B,
    R,
    L
}
